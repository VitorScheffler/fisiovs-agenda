# Como aplicar o patch

Copie as pastas `app/` e o arquivo `middleware.ts` para a raiz do seu projeto fisiovs-agenda, substituindo os existentes.

Estrutura:
```
app/
  page.tsx                        ← redireciona / para /login
  login/
    page.tsx                      ← login sem <form>, com modal criar conta
  api/
    auth/
      register/
        route.ts                  ← endpoint POST /api/auth/register
middleware.ts                     ← redireciona /login se já autenticado
```

## Credenciais do seed
- vitoria@fisiovs.com / admin123
- rafael@fisiovs.com  / fisio123
- larissa@fisiovs.com / sec123
- camila@email.com    / paciente123

## Código de convite para criar conta
FisioVS2026
